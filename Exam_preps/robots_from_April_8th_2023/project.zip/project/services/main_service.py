from project.services.base_service import BaseService


class MainService(BaseService):
    CAPACITY = 30

    def __init__(self, name):
        super().__init__(name, capacity=self.CAPACITY)

    def details(self):
        return f"""{self.name} Main Service:
Robots: {self._get_robot_names()}"""
