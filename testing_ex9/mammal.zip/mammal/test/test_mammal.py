from unittest import TestCase, main

from project.mammal import Mammal


class TestMammal(TestCase):
    def setUp(self) -> None:
        self.tiger = Mammal("Titi", "tiger", "raf")

    def test_correct_initialization(self):
        self.assertEqual(self.tiger.name, "Titi")
        self.assertEqual(self.tiger.type, "tiger")
        self.assertEqual(self.tiger.sound, "raf")
        self.assertEqual(self.tiger._Mammal__kingdom, "animals")

    def test_make_sound(self):
        self.assertEqual(self.tiger.make_sound(), "Titi makes raf")

    def test_get_kingdom(self):
        self.assertEqual(self.tiger._Mammal__kingdom, "animals")

    def test_get_info(self):
        self.assertEqual(self.tiger.info(), "Titi is of type tiger")

if __name__ == "__main__":
    main()